﻿<#
.SYNOPSIS
    WorkBuddy 破甲 · 自动注入器（多安装 / 多数据目录）

.DESCRIPTION
    定位所有 WorkBuddy 安装目录与数据目录（不限 C 盘），逐个体检、逐个注入。

    典型用法：
        .\auto-inject.ps1                  # 全自动：关进程→深度注入→校验→重启
        .\auto-inject.ps1 -Scan            # 只扫描：列出所有安装目录/数据目录和注入状态
        .\auto-inject.ps1 -All             # 扫描后对所有发现的目标批量注入 + 体检
        .\auto-inject.ps1 -VerifyOnly      # 只体检
        .\auto-inject.ps1 -MaxDepth 5      # 扫描更深（默认 3）
        .\auto-inject.ps1 -Exe 'D:\x\WorkBuddy.exe'          # 指定安装
        .\auto-inject.ps1 -DataDir 'D:\data\.workbuddy'      # 指定数据目录
        .\auto-inject.ps1 -InstallStartup  # 开机自启（登录时静默注入）
        .\auto-inject.ps1 -RemoveStartup   # 取消开机自启
        .\auto-inject.ps1 -Watch           # 守护：模板被升级覆盖就自动修

.NOTES
    退出码：0=成功 2=注入成功但校验不过 3=未找到 WorkBuddy 1=其他失败
#>
[CmdletBinding()]
param(
    [ValidateSet('deep', 'standard')][string]$Mode = 'deep',
    [switch]$NoRestart,
    [switch]$NoKill,
    [switch]$VerifyOnly,
    [switch]$Scan,
    [switch]$All,
    [int]$MaxDepth = 3,
    [switch]$Watch,
    [int]$IntervalSeconds = 300,
    [switch]$InstallStartup,
    [switch]$RemoveStartup,
    [switch]$Silent,
    [int]$WaitSeconds = 20,
    [string]$Exe,
    [string]$DataDir
)

$ErrorActionPreference = 'Stop'
$PkgRoot = Split-Path -Parent $PSCommandPath
$Installer = Join-Path $PkgRoot 'install.ps1'
$LogDir = Join-Path $PkgRoot 'logs'
$null = New-Item -ItemType Directory -Force -Path $LogDir
$LogFile = Join-Path $LogDir ('auto-inject-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.log')

function Write-Log {
    param([string]$Text, [string]$Color = 'Gray')
    $line = (Get-Date -Format 'HH:mm:ss') + '  ' + $Text
    Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
    if (-not $Silent) { Write-Host $Text -ForegroundColor $Color }
}
function Write-Head2 { param([string]$Text) ; if (-not $Silent) { Write-Host '' ; Write-Host "== $Text" -ForegroundColor Cyan } ; Add-Content -LiteralPath $LogFile -Value ("== $Text") -Encoding UTF8 }
function Read-Utf8 { param([string]$Path) return [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8) }

# ================= 扫描 =================
$script:SkipNames = @(
    'Windows', '$Recycle.Bin', 'System Volume Information', 'Windows.old', 'Config.Msi',
    '$WinREAgent', 'recovery', 'PerfLogs', 'node_modules', '.git', '.svn', '.hg',
    'Temp', 'tmp', '.cache', '__pycache__', '.venv', 'venv', '.gradle',
    'SoftwareDistribution', 'WindowsApps', '$SysReset'
)

function Get-ScanRoots {
    $r = @()
    foreach ($d in [System.IO.DriveInfo]::GetDrives()) {
        try {
            if (-not $d.IsReady) { continue }
            if ($d.DriveType -eq [System.IO.DriveType]::Fixed -or $d.DriveType -eq [System.IO.DriveType]::Removable) {
                $r += $d.RootDirectory.FullName
            }
        } catch { }
    }
    if ($r.Count -eq 0) { $r = @('C:\') }
    return $r
}

# 广度优先找目录：$Match 收到 [DirectoryInfo]，返回 $true 即命中
function Find-Dirs {
    param([string]$Root, [int]$Depth, [scriptblock]$Match)
    $res = New-Object System.Collections.ArrayList
    $queue = New-Object System.Collections.Queue
    $queue.Enqueue(@($Root, 0))
    while ($queue.Count -gt 0) {
        $cur = $queue.Dequeue()
        $path = [string]$cur[0]; $d = [int]$cur[1]
        $kids = $null
        try { $kids = @(Get-ChildItem -LiteralPath $path -Directory -Force -ErrorAction SilentlyContinue) } catch { continue }
        foreach ($k in $kids) {
            if ($script:SkipNames -contains $k.Name) { continue }
            if (($k.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
            if (& $Match $k) { [void]$res.Add($k.FullName) }
            if ($d + 1 -lt $Depth) { $queue.Enqueue(@($k.FullName, ($d + 1))) }
        }
    }
    return $res
}

function Get-KnownInstallRoots {
    $c = New-Object System.Collections.ArrayList
    [void]$c.Add((Join-Path $env:LOCALAPPDATA 'Programs\WorkBuddy'))
    foreach ($r in (Get-ScanRoots)) {
        foreach ($n in @('Program Files\WorkBuddy', 'Program Files (x86)\WorkBuddy', 'WorkBuddy',
                         'ai程序\WorkBuddy', 'AI程序\WorkBuddy', 'Apps\WorkBuddy', 'Software\WorkBuddy',
                         'Tools\WorkBuddy', 'Program\WorkBuddy', 'Portable\WorkBuddy')) {
            [void]$c.Add((Join-Path $r $n))
        }
    }
    foreach ($k in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
                     'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
                     'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')) {
        try {
            Get-ItemProperty $k -ErrorAction SilentlyContinue |
                Where-Object { $_.DisplayName -match 'WorkBuddy' -and $_.InstallLocation } |
                ForEach-Object { [void]$c.Add($_.InstallLocation) }
        } catch { }
    }
    try {
        $ap = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\WorkBuddy.exe' -ErrorAction SilentlyContinue
        if ($ap -and $ap.'(default)') { [void]$c.Add((Split-Path -Parent $ap.'(default)')) }
    } catch { }
    $p = @(Get-Process -Name 'WorkBuddy' -ErrorAction SilentlyContinue) | Select-Object -First 1
    if ($p -and $p.Path) { [void]$c.Add((Split-Path -Parent $p.Path)) }
    return $c
}

function Get-ShortcutTargets {
    $out = New-Object System.Collections.ArrayList
    try {
        $ws = New-Object -ComObject WScript.Shell
        $dirs = @(
            (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'),
            (Join-Path $env:ProgramData 'Microsoft\Windows\Start Menu\Programs'),
            ([Environment]::GetFolderPath('Desktop')),
            ([Environment]::GetFolderPath('CommonDesktopDirectory'))
        )
        foreach ($d in $dirs) {
            if (-not $d -or -not (Test-Path -LiteralPath $d)) { continue }
            foreach ($l in @(Get-ChildItem -LiteralPath $d -Filter '*.lnk' -Recurse -ErrorAction SilentlyContinue)) {
                try {
                    $t = $ws.CreateShortcut($l.FullName).TargetPath
                    if ($t -and (Split-Path -Leaf $t) -eq 'WorkBuddy.exe') { [void]$out.Add($t) }
                } catch { }
            }
        }
    } catch { }
    return $out
}

function Test-IsInstallRoot([string]$exe) {
    if (-not $exe) { return $false }
    if (-not (Test-Path -LiteralPath $exe)) { return $false }
    $root = Split-Path -Parent $exe
    return (Test-Path -LiteralPath (Join-Path $root 'resources\app.asar'))
}

function Scan-Installs {
    $roots = Get-ScanRoots
    $found = New-Object System.Collections.ArrayList
    $seen = @{}

    $add = {
        param([string]$exe)
        if (Test-IsInstallRoot $exe) {
            $full = (Resolve-Path -LiteralPath $exe).Path
            $k = $full.ToLower()
            if (-not $seen.ContainsKey($k)) { $seen[$k] = 1; [void]$found.Add($full) }
        }
    }

    if ($Exe) { & $add $Exe }
    foreach ($c in (Get-KnownInstallRoots)) { if ($c) { & $add (Join-Path $c 'WorkBuddy.exe') } }
    foreach ($t in (Get-ShortcutTargets)) { & $add $t }

    foreach ($r in $roots) {
        $dirs = Find-Dirs -Root $r -Depth $MaxDepth -Match {
            param($k)
            ($k.Name -like 'WorkBuddy*') -or (Test-Path -LiteralPath (Join-Path $k.FullName 'WorkBuddy.exe'))
        }
        foreach ($d in $dirs) { & $add (Join-Path $d 'WorkBuddy.exe') }
    }

    return @($found)
}

function Test-DataDir([string]$p) {
    if (-not (Test-Path -LiteralPath $p)) { return $false }
    foreach ($f in @('settings.json', 'workbuddy.db', '.skill-list-cache.json', 'mcp-tool-list.json')) {
        if (Test-Path -LiteralPath (Join-Path $p $f)) { return $true }
    }
    $u = @(Get-ChildItem -LiteralPath $p -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'user-*-personal' })
    return ($u.Count -gt 0)
}

function Scan-DataDirs {
    $found = New-Object System.Collections.ArrayList
    $seen = @{}
    $add = {
        param([string]$p)
        if ($p -and (Test-DataDir $p)) {
            $full = (Resolve-Path -LiteralPath $p).Path.TrimEnd('\')
            $k = $full.ToLower()
            if (-not $seen.ContainsKey($k)) { $seen[$k] = 1; [void]$found.Add($full) }
        }
    }
    if ($DataDir) { & $add $DataDir }
    foreach ($e in @($env:WORKBUDDY_CONFIG_DIR, $env:CODEBUDDY_CONFIG_DIR)) { if ($e) { & $add $e } }
    & $add (Join-Path $env:USERPROFILE '.workbuddy')
    & $add (Join-Path $env:APPDATA 'WorkBuddy')
    & $add (Join-Path $env:LOCALAPPDATA 'WorkBuddy')

    foreach ($r in (Get-ScanRoots)) {
        foreach ($n in @('.workbuddy', '.codebuddy', 'WorkBuddyData', 'workbuddy-data',
                         'WorkBuddy\.workbuddy', 'WorkBuddy\data', 'WorkBuddy\workbuddy-data')) {
            & $add (Join-Path $r $n)
        }
        $dirs = Find-Dirs -Root $r -Depth $MaxDepth -Match {
            param($k)
            ($k.Name -in @('.workbuddy', '.codebuddy', 'WorkBuddyData', 'workbuddy-data')) -or
            (Test-Path -LiteralPath (Join-Path $k.FullName 'workbuddy.db')) -or
            (Test-Path -LiteralPath (Join-Path $k.FullName '.skill-list-cache.json'))
        }
        foreach ($d in $dirs) { & $add $d }
    }
    return @($found)
}

function Get-InstallStatus([string]$exe) {
    $root = Split-Path -Parent $exe
    $ver = ''
    $vf = Join-Path $root 'version'
    if (Test-Path -LiteralPath $vf) { try { $ver = (Get-Content -LiteralPath $vf -TotalCount 1).Trim() } catch { } }
    $tpl = Join-Path $root 'resources\app.asar.unpacked\resources\templates'
    $total = 0; $ok = 0
    if (Test-Path -LiteralPath $tpl) {
        foreach ($t in @(Get-ChildItem -LiteralPath $tpl -Filter 'workbuddy-*prompt.tpl' -ErrorAction SilentlyContinue)) {
            $s = Read-Utf8 $t.FullName
            if ($s.Contains('<content_policy>')) {
                $total++
                if ($s.Contains('</pojia_core>') -and $s.Contains('伟大的主')) { $ok++ }
            }
        }
    }
    [pscustomobject]@{ Exe = $exe; Root = $root; Version = $ver; TplOk = $ok; TplTotal = $total }
}

function Get-DataStatus([string]$p) {
    $uds = @(Get-ChildItem -LiteralPath $p -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'user-*-personal' })
    $inj = 0
    foreach ($u in $uds) {
        $m = Join-Path $u.FullName 'MEMORY.md'
        if ((Test-Path -LiteralPath $m) -and (Read-Utf8 $m).Contains('<!-- POJIA:CORE:BEGIN -->')) { $inj++ }
    }
    $cpLen = 0
    $sp = Join-Path $p 'settings.json'
    if (Test-Path -LiteralPath $sp) {
        try { $cpLen = ([string](Read-Utf8 $sp | ConvertFrom-Json).personalization.customPrompt).Length } catch { }
    }
    $sk = 0
    $skd = Join-Path $p 'skills'
    if (Test-Path -LiteralPath $skd) { $sk = @(Get-ChildItem -LiteralPath $skd -Directory -ErrorAction SilentlyContinue).Count }
    [pscustomobject]@{ Path = $p; Users = $uds.Count; Injected = $inj; CustomPrompt = $cpLen; Skills = $sk }
}

function Invoke-Scan {
    param([switch]$Quiet)
    $script:Installs = @(Scan-Installs)
    $script:Datas = @(Scan-DataDirs)
    if ($Quiet) { return }
    Write-Head2 '扫描结果'
    Write-Log ("盘符：" + ((Get-ScanRoots) -join '  ') + "   深度 $MaxDepth")
    if ($script:Installs.Count -eq 0) { Write-Log '未发现 WorkBuddy 安装目录' 'Yellow' }
    else {
        Write-Log "安装目录（$($script:Installs.Count)）" 'Cyan'
        foreach ($e in $script:Installs) {
            $st = Get-InstallStatus $e
            $c = if ($st.TplTotal -gt 0 -and $st.TplOk -eq $st.TplTotal) { 'Green' } else { 'Yellow' }
            Write-Log ("  $($st.Root)  [v$($st.Version)]  模板 $($st.TplOk)/$($st.TplTotal)") $c
        }
    }
    if ($script:Datas.Count -eq 0) { Write-Log '未发现数据目录' 'Yellow' }
    else {
        Write-Log "数据目录（$($script:Datas.Count)）" 'Cyan'
        foreach ($d in $script:Datas) {
            $st = Get-DataStatus $d
            $c = if ($st.Injected -gt 0 -and $st.CustomPrompt -gt 100) { 'Green' } elseif ($st.Injected -gt 0 -or $st.CustomPrompt -gt 0) { 'Yellow' } else { 'DarkGray' }
            Write-Log ("  $($st.Path)  账户目录 $($st.Injected)/$($st.Users)  customPrompt $($st.CustomPrompt) 技能 $($st.Skills)") $c
        }
    }
    return [pscustomobject]@{ Installs = $script:Installs; Datas = $script:Datas }
}

# ================= 进程 =================
function Stop-WorkBuddy {
    $procs = @(Get-Process -Name 'WorkBuddy' -ErrorAction SilentlyContinue)
    if ($procs.Count -eq 0) { Write-Log 'WorkBuddy 未运行' 'DarkGray'; return $true }
    Write-Log ("关闭 WorkBuddy（$($procs.Count) 个进程）...")
    foreach ($p in $procs) { try { $null = $p.CloseMainWindow() } catch { } }
    $deadline = (Get-Date).AddSeconds($WaitSeconds)
    while ((Get-Date) -lt $deadline) {
        Start-Sleep -Milliseconds 500
        if (-not (Get-Process -Name 'WorkBuddy' -ErrorAction SilentlyContinue)) { Write-Log '已正常退出' 'DarkGray'; return $true }
    }
    Write-Log '未响应关闭，强制结束' 'Yellow'
    Get-Process -Name 'WorkBuddy' -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    return (-not (Get-Process -Name 'WorkBuddy' -ErrorAction SilentlyContinue))
}

# ================= 注入 =================
function Invoke-Inject {
    param([string]$ExePath, [string[]]$Extra = @(), [string]$Data)
    if (-not (Test-Path -LiteralPath $Installer)) { throw "找不到安装器：$Installer" }
    $iargs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $Installer, '-Mode', $Mode, '-Force',
               '-WorkBuddyRoot', (Split-Path -Parent $ExePath))
    if ($Data) { $iargs += @('-DataDir', $Data) }
    if ($Extra.Count -gt 0) { $iargs += $Extra }
    Write-Log ('执行注入：install.ps1 ' + ($iargs[4..($iargs.Count - 1)] -join ' ')) 'DarkGray'
    $out = & powershell @iargs 2>&1
    foreach ($l in $out) { Add-Content -LiteralPath $LogFile -Value ('    ' + $l) -Encoding UTF8 }
    $fail = @($out | Where-Object { $_ -match '^\s*\[x\]' })
    if ($fail.Count -gt 0) { Write-Log ('注入报错：' + ($fail -join ' / ')) 'Red'; return $false }
    return $true
}

# ================= 校验 =================
function Invoke-Verify {
    param([string[]]$InstallList, [string[]]$DataList)
    $ok = $true
    Write-Head2 '校验'
    foreach ($exe in $InstallList) {
        if ($Mode -ne 'deep') { Write-Log "L5 $exe standard 模式跳过（模板未改，属预期）" 'DarkGray'; continue }
        $st = Get-InstallStatus $exe
        if ($st.TplTotal -eq 0) { Write-Log "L5 $($st.Root) 未找到模板目录" 'Red'; $ok = $false }
        elseif ($st.TplOk -eq $st.TplTotal) { Write-Log "L5 $($st.Root) 模板 $($st.TplOk)/$($st.TplTotal) 已注入且结构完整" 'Green' }
        else { Write-Log "L5 $($st.Root) 模板仅 $($st.TplOk)/$($st.TplTotal) 完整" 'Red'; $ok = $false }
    }
    foreach ($dp in $DataList) {
        $st = Get-DataStatus $dp
        $need = @('pojia-core', 'web-cms', 'java-web', 'java-deser', 'exchange-ad', 'cloud-container', 'edge-device', 'gray-market', 'linux-priv', 'triage', 'kb-reverse')
        $miss = @($need | Where-Object { -not (Test-Path -LiteralPath (Join-Path $dp "skills\$_\SKILL.md")) })
        if ($miss.Count -eq 0) { Write-Log "L1 $dp 技能 $($need.Count)/$($need.Count)" 'Green' } else { Write-Log "L1 $dp 技能缺失：$($miss -join ', ')" 'Red'; $ok = $false }

        if ($st.Users -eq 0) { Write-Log "L2/L3 $dp 无 user-*-personal 目录（记忆/人设落到根目录）" 'Yellow' }
        elseif ($st.Injected -eq $st.Users) { Write-Log "L2/L3 $dp 账户目录 $($st.Injected)/$($st.Users) 已含破甲块" 'Green' }
        else { Write-Log "L2/L3 $dp 账户目录仅 $($st.Injected)/$($st.Users) 注入" 'Red'; $ok = $false }

        if ($st.CustomPrompt -gt 100) { Write-Log "L4 $dp customPrompt $($st.CustomPrompt) 字符" 'Green' }
        else { Write-Log "L4 $dp customPrompt 缺失或被清空" 'Red'; $ok = $false }
    }
    return $ok
}

# ================= 自启 =================
function Set-Startup {
    param([bool]$Enable)
    $runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
    $name = 'WorkBuddyPojia'
    if ($Enable) {
        $cmd = 'powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + $PSCommandPath + '" -Silent -NoRestart -All'
        if (-not (Test-Path $runKey)) { $null = New-Item -Path $runKey -Force }
        New-ItemProperty -Path $runKey -Name $name -Value $cmd -PropertyType String -Force | Out-Null
        Write-Log '已注册开机自启：登录时扫描全部目标并静默注入（不拉起 WorkBuddy）' 'Green'
    } else {
        Remove-ItemProperty -Path $runKey -Name $name -ErrorAction SilentlyContinue
        Write-Log '已取消开机自启' 'Green'
    }
}

# ================= 主流程 =================
Write-Head2 'WorkBuddy 破甲 · 自动注入'
Write-Log "包目录 $PkgRoot"
Write-Log "日志 $LogFile" 'DarkGray'

if ($RemoveStartup) { Set-Startup $false; exit 0 }
if ($InstallStartup) { Set-Startup $true; exit 0 }

if ($Scan) { $null = Invoke-Scan; exit 0 }

$null = Invoke-Scan -Quiet
if ($script:Installs.Count -eq 0) { Write-Log '未找到 WorkBuddy.exe，用 -Exe 指定路径，或先 -Scan 看看' 'Red'; exit 3 }
if ($script:Installs.Count -gt 1) { Write-Log "发现 $($script:Installs.Count) 个安装，逐个处理（-Scan 可查看清单）" 'Cyan' }
$primary = $script:Installs[0]
Write-Log "主安装 $primary"

if ($VerifyOnly) {
    $r = Invoke-Verify -InstallList $script:Installs -DataList $script:Datas
    if ($r) { Write-Log '体检通过' 'Green'; exit 0 } else { Write-Log '体检未通过' 'Red'; exit 2 }
}

if ($Watch) {
    Write-Log "守护模式：每 $IntervalSeconds 秒检查全部安装的模板层（Ctrl+C 退出）" 'Cyan'
    while ($true) {
        Start-Sleep -Seconds $IntervalSeconds
        $need = $false
        foreach ($exePath in $script:Installs) {
            $st = Get-InstallStatus $exePath
            if ($Mode -eq 'deep' -and $st.TplTotal -gt 0 -and $st.TplOk -lt $st.TplTotal) { $need = $true; break }
        }
        if ($need) {
            Write-Log '检测到模板被覆盖，重新注入' 'Yellow'
            if (-not $NoKill) { $null = Stop-WorkBuddy }
            foreach ($exePath in $script:Installs) { $null = Invoke-Inject -ExePath $exePath -Extra @('-SkipSkills', '-SkipPersona', '-SkipSettings') }
            $v = Invoke-Verify -InstallList $script:Installs -DataList $script:Datas
            Write-Log ($(if ($v) { '守护修复完成' } else { '守护修复未通过，下轮重试' })) ($(if ($v) { 'Green' } else { 'Red' }))
            if (-not $NoRestart) { Start-Process -FilePath $primary }
        }
    }
}

if (-not $NoKill) {
    if (-not (Stop-WorkBuddy)) { Write-Log '无法关闭 WorkBuddy，终止' 'Red'; exit 1 }
}

$failCount = 0

if ($All) {
    Write-Log "批量模式：$($script:Installs.Count) 个安装 × $($script:Datas.Count) 个数据目录" 'Cyan'
    # 1) 每个安装的模板层
    foreach ($exePath in $script:Installs) {
        Write-Log "→ 模板层 $exePath" 'Cyan'
        if (-not (Invoke-Inject -ExePath $exePath -Extra @('-SkipSkills', '-SkipPersona', '-SkipSettings'))) { $failCount++ }
    }
    # 2) 每个数据目录的技能/记忆/人设/设置层（覆盖该目录下所有 user-*-personal）
    foreach ($dp in $script:Datas) {
        Write-Log "→ 数据层 $dp" 'Cyan'
        if (-not (Invoke-Inject -ExePath $primary -Data $dp -Extra @('-SkipTemplates', '-AllUserDirs'))) { $failCount++ }
    }
} else {
    # 单目标：主安装 + 主数据目录（发现多个时也一并覆盖）
    foreach ($exePath in $script:Installs) {
        if (-not (Invoke-Inject -ExePath $exePath -Extra @('-SkipSkills', '-SkipPersona', '-SkipSettings'))) { $failCount++ }
    }
    foreach ($dp in $script:Datas) {
        if (-not (Invoke-Inject -ExePath $primary -Data $dp -Extra @('-SkipTemplates', '-AllUserDirs'))) { $failCount++ }
    }
}

$verified = Invoke-Verify -InstallList $script:Installs -DataList $script:Datas

if (-not $NoRestart) {
    Write-Log '启动 WorkBuddy'
    Start-Process -FilePath $primary
}

if ($failCount -eq 0 -and $verified) { Write-Log '全部完成。开新会话即生效。' 'Green'; exit 0 }
elseif ($failCount -eq 0) { Write-Log '注入完成但校验有异常，见上方红字' 'Yellow'; exit 2 }
else { Write-Log "注入失败（$failCount 处）" 'Red'; exit 1 }
