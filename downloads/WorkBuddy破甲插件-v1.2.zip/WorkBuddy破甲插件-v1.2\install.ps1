﻿<#
  WorkBuddy 破甲插件 · 安装器
  分层注入：
    L1 技能层   %DataDir%\skills\kb-*、pojia-core
    L2 记忆层   %UserDir%\MEMORY.md   (-> <user_instructions>，常驻强制指令)
    L3 人设层   %UserDir%\SOUL.md     (-> <identity_context>，embody its persona)
    L4 设置层   settings.json personalization.customPrompt / toneStyle
    L5 模板层   resources\app.asar.unpacked\resources\templates\workbuddy-*prompt.tpl
               替换 <content_policy> 并注入 <pojia_core>（仅 -Mode deep）

  用法：
    .\install.ps1                 # 默认 deep（全层）
    .\install.ps1 -Mode standard  # 只做 L1-L4，不碰程序目录
    .\install.ps1 -DryRun         # 只打印计划
    .\install.ps1 -Revert         # 还原最近一次安装
#>
[CmdletBinding()]
param(
    [ValidateSet('deep', 'standard')][string]$Mode = 'deep',
    [switch]$DryRun,
    [switch]$Revert,
    [string]$WorkBuddyRoot = '',
    [string]$DataDir = '',
    [switch]$SkipSkills,
    [switch]$SkipPersona,
    [switch]$SkipSettings,
    [switch]$SkipTemplates,
    [switch]$AllUserDirs,
    [switch]$UsePayload,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$PkgRoot     = $PSScriptRoot
$BackupRoot  = Join-Path $PkgRoot 'backups'
$script:KeyPass  = 'pojia-core-v1-workbuddy-2026'
$script:SaltStr  = 'pojia-core-salt-v1'
$script:PlainSrc = 'skills', 'prompt'
$script:SrcRoot  = $PkgRoot

$MarkerBegin = '<!-- POJIA:CORE:BEGIN -->'
$MarkerEnd   = '<!-- POJIA:CORE:END -->'
$PolicyBegin = '<content_policy>'
$PolicyEnd   = '</content_policy>'
$Stamp       = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
$BackupDir   = Join-Path $BackupRoot $Stamp
$script:Actions = New-Object System.Collections.ArrayList

function Write-Step($msg) { Write-Host ("  " + $msg) }
function Write-Head($msg) { Write-Host ""; Write-Host ("== " + $msg) -ForegroundColor Cyan }
function Write-Warn2($msg) { Write-Host ("  [warn] " + $msg) -ForegroundColor Yellow }
function Fail($msg) { Write-Host ("[x] " + $msg) -ForegroundColor Red; exit 1 }

function Read-Utf8($path) { return [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8) }
function Write-Utf8($path, $text) {
    $dir = Split-Path -Parent $path
    if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    [System.IO.File]::WriteAllText($path, $text, (New-Object System.Text.UTF8Encoding($false)))
}

# ---- 加密载荷支持（tools\pojia-pack.ps1 生成 payload\） ----
function Get-AesKey {
    $salt = [Text.Encoding]::UTF8.GetBytes($script:SaltStr)
    $k = New-Object System.Security.Cryptography.Rfc2898DeriveBytes($script:KeyPass, $salt, 100000)
    try { return $k.GetBytes(32) } finally { $k.Dispose() }
}
function Unprotect-File($srcPath, $dstPath) {
    $blob = [IO.File]::ReadAllBytes($srcPath)
    if ($blob.Length -le 16) { throw "密文损坏: $srcPath" }
    $aes = [System.Security.Cryptography.Aes]::Create()
    try {
        $aes.Mode = 'CBC'; $aes.Padding = 'PKCS7'; $aes.Key = (Get-AesKey)
        $iv = New-Object byte[] 16
        [Array]::Copy($blob, 0, $iv, 0, 16)
        $aes.IV = $iv
        $ct = New-Object byte[] ($blob.Length - 16)
        [Array]::Copy($blob, 16, $ct, 0, $ct.Length)
        $dec = $aes.CreateDecryptor()
        $plain = $dec.TransformFinalBlock($ct, 0, $ct.Length)
        $dir = Split-Path -Parent $dstPath
        if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        [IO.File]::WriteAllBytes($dstPath, $plain)
    } finally { $aes.Dispose() }
}
function Expand-Payload {
    $idx = Join-Path $PkgRoot 'payload\index.json'
    if (-not (Test-Path -LiteralPath $idx)) { return $false }
    $plainSkills = Test-Path -LiteralPath (Join-Path $PkgRoot 'skills')
    if ($plainSkills -and -not $UsePayload) { return $false }
    $obj = (Read-Utf8 $idx) | ConvertFrom-Json
    $tmp = Join-Path ([IO.Path]::GetTempPath()) ('pojia-src-' + $Stamp)
    $n = 0
    foreach ($e in $obj.entries) {
        $rel = $e.path.Replace('/', '\')
        $src = Join-Path $PkgRoot ('payload\' + $rel + '.enc')
        if (-not (Test-Path -LiteralPath $src)) { continue }
        Unprotect-File $src (Join-Path $tmp $rel)
        $n++
    }
    Write-Step ("解密载荷 " + $n + " 个文件 -> " + $tmp)
    $script:SrcRoot = $tmp
    return $true
}

function Add-Action($kind, $path, $backupPath) {
    [void]$script:Actions.Add([pscustomobject]@{ kind = $kind; path = $path; backup = $backupPath })
    if (-not $DryRun) { Save-Manifest }
}
function Save-Manifest() {
    if ($DryRun) { return }
    if (-not (Test-Path -LiteralPath $BackupDir)) { New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null }
    $m = [pscustomobject]@{
        stamp        = $Stamp
        mode         = $Mode
        workbuddy    = $script:WorkBuddyRoot
        dataDir      = $script:DataDir
        userDir      = $script:UserDir
        createdUtc   = (Get-Date).ToUniversalTime().ToString('o')
        actions      = $script:Actions
    }
    $m | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $BackupDir 'manifest.json') -Encoding UTF8
}

function Backup-File($path) {
    if (-not (Test-Path -LiteralPath $path)) { return $null }
    $dest = Join-Path $BackupDir ('f' + ($script:Actions.Count + 1) + '_' + (Split-Path -Leaf $path))
    if (-not $DryRun) {
        New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null
        Copy-Item -LiteralPath $path -Destination $dest -Force
    }
    return $dest
}

# ---------- 定位 ----------
function Resolve-WorkBuddyRoot {
    if ($WorkBuddyRoot) {
        if (Test-Path (Join-Path $WorkBuddyRoot 'resources\app.asar')) { return (Resolve-Path $WorkBuddyRoot).Path }
        Fail "指定的 WorkBuddyRoot 不含 resources\app.asar：$WorkBuddyRoot"
    }
    $cands = New-Object System.Collections.ArrayList
    foreach ($p in @(
            'E:\ai程序\WorkBuddy',
            (Join-Path $env:LOCALAPPDATA 'Programs\WorkBuddy'),
            (Join-Path $env:LOCALAPPDATA 'Programs\workbuddy'),
            (Join-Path $env:ProgramFiles 'WorkBuddy'),
            (Join-Path ${env:ProgramFiles(x86)} 'WorkBuddy'))) {
        if ($p) { [void]$cands.Add($p) }
    }
    $keys = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    foreach ($k in $keys) {
        try {
            Get-ItemProperty $k -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -match 'WorkBuddy' -and $_.InstallLocation } | ForEach-Object { [void]$cands.Add($_.InstallLocation) }
        } catch { }
    }
    try {
        $ap = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\WorkBuddy.exe' -ErrorAction SilentlyContinue
        if ($ap -and $ap.'(default)') { [void]$cands.Add((Split-Path -Parent $ap.'(default)')) }
    } catch { }
    foreach ($c in $cands) {
        if ($c -and (Test-Path (Join-Path $c 'resources\app.asar'))) { return (Resolve-Path $c).Path }
    }
    Fail "没找到 WorkBuddy 安装目录。请用 -WorkBuddyRoot 指定（含 resources\app.asar 的那层）。"
}

function Resolve-DataDir {
    if ($DataDir) { if (-not (Test-Path $DataDir)) { if (-not $DryRun) { New-Item -ItemType Directory -Force -Path $DataDir | Out-Null } }; return $DataDir }
    foreach ($e in @($env:WORKBUDDY_CONFIG_DIR, $env:CODEBUDDY_CONFIG_DIR)) { if ($e -and (Test-Path $e)) { return $e } }
    $d = Join-Path $env:USERPROFILE '.workbuddy'
    if (-not (Test-Path $d)) { if (-not $DryRun) { New-Item -ItemType Directory -Force -Path $d | Out-Null } }
    return $d
}

function Resolve-UserDir($root) {
    $dirs = @(Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'user-*-personal' })
    if ($dirs.Count -eq 0) { Write-Warn2 "未发现 user-*-personal 目录，记忆/人设层落到 $root 根目录"; return $root }
    $withSoul = $dirs | Where-Object { Test-Path (Join-Path $_.FullName 'SOUL.md') }
    if ($withSoul) { return ($withSoul | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName }
    return ($dirs | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName
}

# ---------- 块写入 ----------
function Set-MarkerBlock($path, $blockFile) {
    $block = (Read-Utf8 $blockFile).Trim()
    $cur = ''
    if (Test-Path -LiteralPath $path) { $cur = Read-Utf8 $path }
    if ($cur.Contains($MarkerBegin) -and $cur.Contains($MarkerEnd)) {
        $s = $cur.IndexOf($MarkerBegin)
        $e = $cur.IndexOf($MarkerEnd) + $MarkerEnd.Length
        $new = $cur.Substring(0, $s) + $block + $cur.Substring($e)
        $kind = 'modify'
    } elseif ($cur.Trim().Length -eq 0) {
        $new = $block + "`r`n"
        $kind = 'create'
    } else {
        $new = $cur.TrimEnd() + "`r`n`r`n" + $block + "`r`n"
        $kind = 'modify'
    }
    if ($new -eq $cur) { Write-Step "$path 已含破甲块，跳过"; return }
    if ($DryRun) { Write-Step "[DRY] 写入块 -> $path ($kind)"; return }
    $b = if ($kind -eq 'modify') { Backup-File $path } else { $null }
    Add-Action $kind $path $b
    Write-Utf8 $path $new
    Write-Step "写入 $path"
}

# ---------- 安装 ----------
function Invoke-Install {
    Write-Host "WorkBuddy 破甲插件 v1.2  · 模式=$Mode  · $(if($DryRun){'预览'}else{'安装'})" -ForegroundColor Green

    if (-not $DryRun -and -not $Revert -and -not $Force) {
        $procs = @(Get-Process -Name 'WorkBuddy' -ErrorAction SilentlyContinue)
        if ($procs.Count -gt 0) { Fail "WorkBuddy 正在运行（PID $($procs.Id -join ',')），请完全退出后再执行（或加 -Force）。" }
    }

    $null = Expand-Payload


    Write-Head '定位环境'
    $script:WorkBuddyRoot = Resolve-WorkBuddyRoot
    $script:DataDir = Resolve-DataDir
    $script:UserDir = Resolve-UserDir $script:DataDir
    $script:UserDirs = @($script:UserDir)
    if ($AllUserDirs) {
        $all = @(Get-ChildItem -LiteralPath $script:DataDir -Directory -ErrorAction SilentlyContinue |
                 Where-Object { $_.Name -like 'user-*-personal' } | ForEach-Object { $_.FullName })
        if ($all.Count -gt 0) { $script:UserDirs = $all }
    }
    Write-Step "WorkBuddy   : $script:WorkBuddyRoot"
    Write-Step "数据目录    : $script:DataDir"
    Write-Step "用户目录    : $($script:UserDirs -join ' ; ')"
    Write-Step "备份目录    : $BackupDir"

    # L1 技能层
    if (-not $SkipSkills) {
        Write-Head 'L1 技能层 → skills'
        $skillsDir = Join-Path $script:DataDir 'skills'
        if (-not (Test-Path $skillsDir)) {
            if ($DryRun) { Write-Step "[DRY] 创建目录 $skillsDir" }
            else { New-Item -ItemType Directory -Force -Path $skillsDir | Out-Null; Add-Action 'create-dir' $skillsDir }
        }
        foreach ($src in Get-ChildItem (Join-Path $script:SrcRoot 'skills') -Directory) {
            $dest = Join-Path $skillsDir $src.Name
            if (Test-Path -LiteralPath $dest) {
                $bk = Join-Path $BackupDir ('d' + ($script:Actions.Count + 1) + '_' + $src.Name)
                if ($DryRun) { Write-Step "[DRY] 覆盖技能 $($src.Name)（备份原目录）"; continue }
                New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null
                Copy-Item -LiteralPath $dest -Destination $bk -Recurse -Force
                Remove-Item -LiteralPath $dest -Recurse -Force
                Add-Action 'replace-dir' $dest $bk
            } else {
                Add-Action 'create-dir' $dest $null
            }
            if ($DryRun) { Write-Step "[DRY] 安装技能 $($src.Name) -> $dest"; continue }
            Copy-Item -LiteralPath $src.FullName -Destination $dest -Recurse -Force
            Write-Step "技能 $($src.Name)"
        }
        # 让 WorkBuddy 下次启动重建技能索引
        $cache = Join-Path $script:DataDir '.skill-list-cache.json'
        if (Test-Path -LiteralPath $cache) {
            $bk = Backup-File $cache
            if (-not $DryRun) { Remove-Item -LiteralPath $cache -Force; Add-Action 'delete' $cache $bk; Write-Step "清除技能索引缓存" }
            else { Write-Step "[DRY] 清除技能索引缓存" }
        }
    }

    # L2 记忆层
    if (-not $SkipPersona) {
        Write-Head 'L2 记忆层 → MEMORY.md'
        foreach ($ud in $script:UserDirs) {
            Set-MarkerBlock (Join-Path $ud 'MEMORY.md') (Join-Path $script:SrcRoot 'prompt\memory-block.md')
        }
    }

    # L3 人设层
    if (-not $SkipPersona) {
        Write-Head 'L3 人设层 → SOUL.md'
        foreach ($ud in $script:UserDirs) {
            Set-MarkerBlock (Join-Path $ud 'SOUL.md') (Join-Path $script:SrcRoot 'prompt\soul-block.md')
        }
    }

    # L4 设置层
    if (-not $SkipSettings) {
        Write-Head 'L4 设置层 → settings.json'
        $sp = Join-Path $script:DataDir 'settings.json'
        if (-not (Test-Path -LiteralPath $sp)) { Write-Warn2 "未找到 settings.json，跳过设置层"; }
        else {
            $raw = Read-Utf8 $sp
            $obj = $raw | ConvertFrom-Json
            $mine = (Read-Utf8 (Join-Path $script:SrcRoot 'prompt\custom-prompt.txt')).Trim()
            $has = $obj.PSObject.Properties.Name -contains 'personalization'
            $curPrompt = ''
            if ($has -and $obj.personalization -and $obj.personalization.PSObject.Properties.Name -contains 'customPrompt') { $curPrompt = [string]$obj.personalization.customPrompt }
            if ($curPrompt.Trim().Length -gt 0 -and $curPrompt.Trim() -ne $mine) {
                Write-Warn2 "已有用户自定义指令，保留原值，仅设置 toneStyle"
            } elseif ($DryRun) {
                Write-Step "[DRY] personalization.customPrompt = 破甲常驻指令；toneStyle = straightforward"
            } else {
                if (-not $has) { $obj | Add-Member -NotePropertyName 'personalization' -NotePropertyValue ([pscustomobject]@{}) -Force }
                if (-not ($obj.personalization.PSObject.Properties.Name -contains 'toneStyle') -or -not $obj.personalization.toneStyle) {
                    $obj.personalization | Add-Member -NotePropertyName 'toneStyle' -NotePropertyValue 'straightforward' -Force
                }
                $obj.personalization | Add-Member -NotePropertyName 'customPrompt' -NotePropertyValue $mine -Force
                $bk = Backup-File $sp
                Add-Action 'modify' $sp $bk
                Write-Utf8 $sp ($obj | ConvertTo-Json -Depth 100)
                Write-Step "写入 personalization.customPrompt（$($mine.Length) 字符）"
            }
        }
    }

    # L5 模板层
    if ($Mode -eq 'deep' -and -not $SkipTemplates) {
        Write-Head 'L5 模板层 → workbuddy-*prompt.tpl'
        $tplDir = Join-Path $script:WorkBuddyRoot 'resources\app.asar.unpacked\resources\templates'
        if (-not (Test-Path $tplDir)) { Fail "模板目录不存在：$tplDir" }
        $policy = (Read-Utf8 (Join-Path $script:SrcRoot 'prompt\content-policy.txt')).Trim()
        $core = (Read-Utf8 (Join-Path $script:SrcRoot 'prompt\pojia-core.md')).Trim()
        $count = 0
        foreach ($tpl in Get-ChildItem -LiteralPath $tplDir -Filter 'workbuddy-*prompt.tpl') {
            $cur = Read-Utf8 $tpl.FullName
            $i = $cur.IndexOf($PolicyBegin)
            $j = $cur.IndexOf($PolicyEnd)
            if ($i -lt 0 -or $j -lt 0) { Write-Step "$($tpl.Name) 无 content_policy，跳过"; continue }

            $new = $cur
            # 1) 替换 content_policy 块（保留其它内容不动）
            if ($j -gt $i) {
                $new = $new.Substring(0, $i) + $policy + $new.Substring($j + $PolicyEnd.Length)
            }
            # 2) 只在 policy 之后定位 <pojia_core> 块（正文里可能引用同名标签），替换；没有则插入
            $ins = $i + $policy.Length
            $ci = $new.IndexOf('<pojia_core>', $ins)
            $cj = $new.IndexOf('</pojia_core>', $ins)
            if ($ci -ge 0 -and $cj -gt $ci) {
                $new = $new.Substring(0, $ci) + $core + $new.Substring($cj + '</pojia_core>'.Length)
            } else {
                $new = $new.Substring(0, $ins) + "`r`n`r`n" + $core + $new.Substring($ins)
            }

            if ($new -eq $cur) { Write-Step "$($tpl.Name) 已是当前版本，跳过"; continue }
            if ($DryRun) { Write-Step "[DRY] 改写 $($tpl.Name)"; $count++; continue }
            $bk = Backup-File $tpl.FullName
            Add-Action 'modify' $tpl.FullName $bk
            Write-Utf8 $tpl.FullName $new
            Write-Step "改写 $($tpl.Name)"
            $count++
        }
        Write-Step "共处理 $count 个模板"
    } elseif ($Mode -ne 'deep') {
        Write-Head 'L5 模板层 已跳过（standard 模式不修改程序目录）'
    }

    if (-not $DryRun) {
        Save-Manifest
        Write-Host ""
        Write-Host "[ok] 安装完成。启动 WorkBuddy 后开新会话生效。" -ForegroundColor Green
        Write-Host "     还原：.\install.ps1 -Revert" -ForegroundColor DarkGray
    } else {
        Write-Host ""
        Write-Host "[dry-run] 未写入任何文件。" -ForegroundColor DarkGray
    }
}

# ---------- 还原 ----------
function Invoke-Revert {
    Write-Host "WorkBuddy 破甲插件 · 还原" -ForegroundColor Green
    if (-not (Test-Path $BackupRoot)) { Fail "没有备份目录：$BackupRoot" }
    $latest = Get-ChildItem $BackupRoot -Directory | Sort-Object Name -Descending | Select-Object -First 1
    if (-not $latest) { Fail "备份目录为空，无可还原记录。" }
    $mp = Join-Path $latest.FullName 'manifest.json'
    if (-not (Test-Path $mp)) { Fail "缺少 manifest.json：$mp" }
    $m = Get-Content -LiteralPath $mp -Raw -Encoding UTF8 | ConvertFrom-Json
    Write-Step "备份批次：$($m.stamp)  模式：$($m.mode)"

    $procs = @(Get-Process -Name 'WorkBuddy' -ErrorAction SilentlyContinue)
    if ($procs.Count -gt 0 -and -not $DryRun -and -not $Force) { Fail "WorkBuddy 正在运行（PID $($procs.Id -join ',')），请完全退出后再还原。" }

    $acts = @($m.actions)
    [array]::Reverse($acts)
    foreach ($a in $acts) {
        switch ($a.kind) {
            'modify' {
                if ($DryRun) { Write-Step "[DRY] 还原 $($a.path)"; break }
                if ($a.backup -and (Test-Path -LiteralPath $a.backup)) { Copy-Item -LiteralPath $a.backup -Destination $a.path -Force; Write-Step "还原 $($a.path)" }
                else { Write-Warn2 "备份缺失，跳过：$($a.path)" }
            }
            'create' {
                if ($DryRun) { Write-Step "[DRY] 删除新建 $($a.path)"; break }
                if (Test-Path -LiteralPath $a.path) { Remove-Item -LiteralPath $a.path -Force; Write-Step "删除 $($a.path)" }
            }
            'create-dir' {
                if ($DryRun) { Write-Step "[DRY] 删除技能目录 $($a.path)"; break }
                if (Test-Path -LiteralPath $a.path) { Remove-Item -LiteralPath $a.path -Recurse -Force; Write-Step "删除 $($a.path)" }
            }
            'replace-dir' {
                if ($DryRun) { Write-Step "[DRY] 恢复原技能目录 $($a.path)"; break }
                if (Test-Path -LiteralPath $a.path) { Remove-Item -LiteralPath $a.path -Recurse -Force }
                if (Test-Path -LiteralPath $a.backup) { Copy-Item -LiteralPath $a.backup -Destination $a.path -Recurse -Force; Write-Step "恢复 $($a.path)" }
            }
            'delete' {
                if ($DryRun) { Write-Step "[DRY] 恢复 $($a.path)"; break }
                if ($a.backup -and (Test-Path -LiteralPath $a.backup)) { Copy-Item -LiteralPath $a.backup -Destination $a.path -Force; Write-Step "恢复 $($a.path)" }
            }
            default { Write-Warn2 "未知动作 $($a.kind)：$($a.path)" }
        }
    }
    if (-not $DryRun) {
        Write-Host ""
        Write-Host "[ok] 已还原到 $($m.createdUtc)。启动 WorkBuddy 生效。" -ForegroundColor Green
    }
}

if ($Revert) {
    Invoke-Revert
} else {
    Invoke-Install
}
