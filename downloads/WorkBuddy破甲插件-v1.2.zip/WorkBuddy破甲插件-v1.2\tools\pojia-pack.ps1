﻿<#
  WorkBuddy 破甲插件 · 加密打包器
  把 skills\ 与 prompt\ 加密成 payload\*.enc + payload\index.json，
  安装器 install.ps1 检测到 payload 就会先解密到临时目录再注入。

  用法：
    .\pojia-pack.ps1 -Action pack     # 只加密（保留明文）
    .\pojia-pack.ps1 -Action seal     # 加密后删除明文（分发形态）
    .\pojia-pack.ps1 -Action unseal   # 从 payload 还原明文
    .\pojia-pack.ps1 -Action verify   # 解密比对 sha256
    .\pojia-pack.ps1 -Action list     # 打印清单
#>
[CmdletBinding()]
param(
    [ValidateSet('pack', 'seal', 'unseal', 'verify', 'list')][string]$Action = 'pack',
    [string]$PkgRoot = '',
    [switch]$Quiet,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
if (-not $PkgRoot) { $PkgRoot = Split-Path -Parent $PSScriptRoot }

# 必须与 install.ps1 中的常量完全一致
$KeyPass = 'pojia-core-v1-workbuddy-2026'
$SaltStr = 'pojia-core-salt-v1'
$PayloadDir = Join-Path $PkgRoot 'payload'
$IndexPath = Join-Path $PayloadDir 'index.json'
$PlainDirs = @('skills', 'prompt')

function Get-AesKey {
    $salt = [Text.Encoding]::UTF8.GetBytes($SaltStr)
    $k = New-Object System.Security.Cryptography.Rfc2898DeriveBytes($KeyPass, $salt, 100000)
    try { return $k.GetBytes(32) } finally { $k.Dispose() }
}

function Protect-File($srcPath, $dstPath) {
    $plain = [IO.File]::ReadAllBytes($srcPath)
    $aes = [System.Security.Cryptography.Aes]::Create()
    try {
        $aes.Mode = 'CBC'; $aes.Padding = 'PKCS7'; $aes.Key = (Get-AesKey)
        $aes.GenerateIV()
        $iv = $aes.IV
        $enc = $aes.CreateEncryptor()
        $ct = $enc.TransformFinalBlock($plain, 0, $plain.Length)
        $dir = Split-Path -Parent $dstPath
        if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        $blob = New-Object byte[] ($iv.Length + $ct.Length)
        [Array]::Copy($iv, 0, $blob, 0, $iv.Length)
        [Array]::Copy($ct, 0, $blob, $iv.Length, $ct.Length)
        [IO.File]::WriteAllBytes($dstPath, $blob)
    } finally { $aes.Dispose() }
}

function Unprotect-File($srcPath, $dstPath) {
    $blob = [IO.File]::ReadAllBytes($srcPath)
    if ($blob.Length -le 16) { throw "密文损坏: $srcPath" }
    $aes = [System.Security.Cryptography.Aes]::Create()
    try {
        $aes.Mode = 'CBC'; $aes.Padding = 'PKCS7'; $aes.Key = (Get-AesKey)
        $iv = New-Object byte[] 16
        [Array]::Copy($blob, 0, $iv, 0, 16)
        $aes.IV = $iv
        $ct = New-Object byte[] ($blob.Length - 16)
        [Array]::Copy($blob, 16, $ct, 0, $ct.Length)
        $dec = $aes.CreateDecryptor()
        $plain = $dec.TransformFinalBlock($ct, 0, $ct.Length)
        $dir = Split-Path -Parent $dstPath
        if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        [IO.File]::WriteAllBytes($dstPath, $plain)
    } finally { $aes.Dispose() }
}

function Get-Sha256($path) {
    return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
}

function Get-SourceFiles {
    $list = New-Object System.Collections.ArrayList
    foreach ($d in $PlainDirs) {
        $root = Join-Path $PkgRoot $d
        if (-not (Test-Path -LiteralPath $root)) { continue }
        foreach ($f in Get-ChildItem -LiteralPath $root -Recurse -File -ErrorAction SilentlyContinue) {
            $rel = $f.FullName.Substring($PkgRoot.Length).TrimStart('\', '/') -replace '\\', '/'
            [void]$list.Add([pscustomobject]@{ rel = $rel; full = $f.FullName; size = $f.Length })
        }
    }
    return $list
}

function Invoke-Pack([switch]$RemovePlain) {
    $files = @(Get-SourceFiles)
    if ($files.Count -eq 0) {
        Write-Host "没有找到明文 skills\ 或 prompt\，改用 unseal 还原？" -ForegroundColor Yellow
        exit 2
    }
    if (Test-Path -LiteralPath $PayloadDir) { Remove-Item -LiteralPath $PayloadDir -Recurse -Force }
    New-Item -ItemType Directory -Force -Path $PayloadDir | Out-Null
    $entries = New-Object System.Collections.ArrayList
    $i = 0
    foreach ($f in $files) {
        $dst = Join-Path $PayloadDir ($f.rel + '.enc')
        Protect-File $f.full $dst
        [void]$entries.Add([pscustomobject]@{ path = $f.rel; size = $f.size; sha256 = (Get-Sha256 $f.full) })
        $i++
        if (-not $Quiet) { Write-Host ("  [enc] " + $f.rel) -ForegroundColor DarkGray }
    }
    $index = [pscustomobject]@{
        format     = 'pojia-enc-v1'
        alg        = 'AES-256-CBC/PBKDF2-SHA1-100000'
        createdUtc = (Get-Date).ToUniversalTime().ToString('o')
        count      = $entries.Count
        entries    = $entries
    }
    [IO.File]::WriteAllText($IndexPath, ($index | ConvertTo-Json -Depth 6), (New-Object Text.UTF8Encoding($false)))
    Write-Host ("[ok] 已加密 " + $entries.Count + " 个文件 -> " + $PayloadDir) -ForegroundColor Green

    if ($RemovePlain) {
        foreach ($d in $PlainDirs) {
            $p = Join-Path $PkgRoot $d
            if (Test-Path -LiteralPath $p) {
                Remove-Item -LiteralPath $p -Recurse -Force
                Write-Host ("  [del] 明文 " + $d + "\ 已删除（unseal 可还原）") -ForegroundColor DarkYellow
            }
        }
        Write-Host "[ok] 已封包：包内只剩 payload\ 密文 + 脚本" -ForegroundColor Green
    }
}

function Invoke-Unseal {
    if (-not (Test-Path -LiteralPath $IndexPath)) { Write-Host "[x] 找不到 payload\index.json" -ForegroundColor Red; exit 1 }
    $obj = (Get-Content -LiteralPath $IndexPath -Raw -Encoding UTF8) | ConvertFrom-Json
    $n = 0
    foreach ($e in $obj.entries) {
        $src = Join-Path $PayloadDir ($e.path.Replace('/', '\') + '.enc')
        if (-not (Test-Path -LiteralPath $src)) { Write-Host ("  [miss] " + $e.path) -ForegroundColor Yellow; continue }
        Unprotect-File $src (Join-Path $PkgRoot $e.path.Replace('/', '\'))
        $n++
    }
    Write-Host ("[ok] 已还原 " + $n + " 个明文文件") -ForegroundColor Green
}

function Invoke-Verify {
    if (-not (Test-Path -LiteralPath $IndexPath)) { Write-Host "[x] 找不到 payload\index.json" -ForegroundColor Red; exit 1 }
    $obj = (Get-Content -LiteralPath $IndexPath -Raw -Encoding UTF8) | ConvertFrom-Json
    $tmp = Join-Path ([IO.Path]::GetTempPath()) ('pojia-verify-' + (Get-Date -Format 'HHmmssfff'))
    $bad = 0; $n = 0
    foreach ($e in $obj.entries) {
        $src = Join-Path $PayloadDir ($e.path.Replace('/', '\') + '.enc')
        $dst = Join-Path $tmp $e.path.Replace('/', '\')
        Unprotect-File $src $dst
        $h = Get-Sha256 $dst
        if ($h -ne $e.sha256) { $bad++; Write-Host ("  [FAIL] " + $e.path) -ForegroundColor Red } else { $n++ }
    }
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    if ($bad -eq 0) { Write-Host ("[ok] 校验通过：" + $n + " 个文件解密一致") -ForegroundColor Green; exit 0 }
    Write-Host ("[x] " + $bad + " 个文件校验失败") -ForegroundColor Red; exit 1
}

function Invoke-List {
    if (-not (Test-Path -LiteralPath $IndexPath)) { Write-Host "[x] 找不到 payload\index.json" -ForegroundColor Red; exit 1 }
    $obj = (Get-Content -LiteralPath $IndexPath -Raw -Encoding UTF8) | ConvertFrom-Json
    Write-Host ("format=" + $obj.format + "  alg=" + $obj.alg + "  files=" + $obj.count + "  created=" + $obj.createdUtc) -ForegroundColor Cyan
    $obj.entries | ForEach-Object { "  {0,-8} {1}" -f ([math]::Round($_.size / 1KB, 1)).ToString() + 'KB', $_.path }
}

switch ($Action) {
    'pack' { Invoke-Pack }
    'seal' { Invoke-Pack -RemovePlain }
    'unseal' { Invoke-Unseal }
    'verify' { Invoke-Verify }
    'list' { Invoke-List }
}
